#ifndef __APP_H__
#define __APP_H__
#include <Arduino.h>
#define SW_PIN 2
#define X_PIN A0
#define Y_PIN A1
#define M_PIN 3
#endif
